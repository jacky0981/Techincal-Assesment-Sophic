import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../core/auth.service';
import { TaskItem, TaskService, Priority } from '../../core/task.service';
import { errorMessage } from '../../core/api-error';

@Component({ selector: 'app-tasks', imports: [ReactiveFormsModule], templateUrl: './tasks.component.html' })
export class TasksComponent {
  private readonly api = inject(TaskService);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly fb = inject(FormBuilder);
  readonly tasks = signal<TaskItem[]>([]);
  readonly loading = signal(false);
  readonly busy = signal(false);
  readonly error = signal('');
  editingId: string | null = null;

  readonly form = this.fb.nonNullable.group({
    title: ['', [Validators.required, Validators.maxLength(120), Validators.pattern(/\S/)]],
    description: ['', Validators.maxLength(2000)],
    priority: ['Medium' as Priority, Validators.required],
    dueDate: ['']
  });

  constructor() { this.load(); }

  load(): void {
    this.loading.set(true);
    this.error.set('');
    this.api.list().pipe(finalize(() => this.loading.set(false))).subscribe({
      next: tasks => this.tasks.set(tasks),
      error: error => this.error.set(errorMessage(error))
    });
  }

  edit(task: TaskItem): void {
    this.editingId = task.id;
    this.form.setValue({
      title: task.title, description: task.description ?? '',
      priority: task.priority, dueDate: task.dueDate ?? ''
    });
  }

  cancel(): void {
    this.editingId = null;
    this.form.reset({ title: '', description: '', priority: 'Medium', dueDate: '' });
  }

  save(): void {
    if (this.busy() || this.loading()) return;
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const values = this.form.getRawValue();
    const task = {
      title: values.title.trim(), description: values.description.trim() || null,
      priority: values.priority, dueDate: values.dueDate || null
    };
    const request = this.editingId ? this.api.update(this.editingId, task) : this.api.create(task);
    this.busy.set(true);
    this.error.set('');
    request.pipe(finalize(() => this.busy.set(false))).subscribe({
      next: () => { this.cancel(); this.load(); },
      error: error => this.error.set(errorMessage(error))
    });
  }

  toggle(task: TaskItem): void {
    if (this.busy() || this.loading()) return;
    this.busy.set(true);
    this.error.set('');
    this.api.setStatus(task.id, task.status === 'Todo' ? 'Done' : 'Todo')
      .pipe(finalize(() => this.busy.set(false))).subscribe({
        next: () => this.load(),
        error: error => this.error.set(errorMessage(error))
      });
  }

  remove(task: TaskItem): void {
    if (this.busy() || this.loading() || !confirm('Delete this task?')) return;
    this.busy.set(true);
    this.error.set('');
    this.api.delete(task.id).pipe(finalize(() => this.busy.set(false))).subscribe({
      next: () => { if (this.editingId === task.id) this.cancel(); this.load(); },
      error: error => this.error.set(errorMessage(error))
    });
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigate(['/login']);
  }
}
