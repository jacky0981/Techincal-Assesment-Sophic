import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs';

export interface LoginResponse { token: string; expiresAt: string; }
const STORAGE_KEY = 'taskflow.session';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);

  login(email: string, password: string) {
    return this.http.post<LoginResponse>('/api/auth/login', { email, password }).pipe(
      tap(session => localStorage.setItem(STORAGE_KEY, JSON.stringify(session)))
    );
  }

  token(): string | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const session: LoginResponse = JSON.parse(raw);
      if (typeof session.token !== 'string' || !session.token ||
          !Number.isFinite(Date.parse(session.expiresAt)) || Date.parse(session.expiresAt) <= Date.now()) {
        this.logout();
        return null;
      }
      return session.token;
    } catch { this.logout(); return null; }
  }

  logout(): void { localStorage.removeItem(STORAGE_KEY); }
}
