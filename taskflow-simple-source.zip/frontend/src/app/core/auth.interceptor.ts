import { inject } from '@angular/core';
import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  // Do not leak tokens to arbitrary external URLs or attach stale tokens to login.
  const isProtectedApi = request.url.startsWith('/api/') && request.url !== '/api/auth/login';
  const token = isProtectedApi ? auth.token() : null;
  const outgoing = token ? request.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : request;
  return next(outgoing).pipe(catchError((error: HttpErrorResponse) => {
    if (isProtectedApi && error.status === 401) {
      auth.logout();
      void router.navigate(['/login'], { queryParams: { expired: 'true' } });
    }
    return throwError(() => error);
  }));
};
