import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export type Priority = 'Low' | 'Medium' | 'High';
export type Status = 'Todo' | 'Done';
export interface TaskInput { title: string; description: string | null; priority: Priority; dueDate: string | null; }
export interface TaskItem extends TaskInput { id: string; status: Status; createdAt: string; }

@Injectable({ providedIn: 'root' })
export class TaskService {
  private readonly http = inject(HttpClient);
  list() { return this.http.get<TaskItem[]>('/api/tasks'); }
  create(task: TaskInput) { return this.http.post<TaskItem>('/api/tasks', task); }
  update(id: string, task: TaskInput) { return this.http.put<TaskItem>(`/api/tasks/${id}`, task); }
  setStatus(id: string, status: Status) { return this.http.patch<TaskItem>(`/api/tasks/${id}/status`, { status }); }
  delete(id: string) { return this.http.delete<void>(`/api/tasks/${id}`); }
}
