import { HttpErrorResponse } from '@angular/common/http';

export function errorMessage(error: unknown): string {
  if (!(error instanceof HttpErrorResponse)) return 'Something went wrong. Please try again.';
  if (error.status === 0) return 'Cannot reach the server. Check your connection and try again.';
  return typeof error.error?.message === 'string' ? error.error.message : 'The request failed. Please try again.';
}
