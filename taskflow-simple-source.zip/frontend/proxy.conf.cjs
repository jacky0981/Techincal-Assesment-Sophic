const target = process.env.TASKFLOW_API_TARGET ?? 'http://127.0.0.1:18080';
module.exports = { '/api/**': { target, secure: false }, '/swagger/**': { target, secure: false } };
