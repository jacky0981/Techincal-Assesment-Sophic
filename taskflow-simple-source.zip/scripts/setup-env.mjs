import { randomBytes } from 'node:crypto';
import { existsSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { root, readEnv } from './env.mjs';

// Create local configuration once. Existing credentials are never overwritten.
if (!existsSync(resolve(root, '.env'))) {
  writeFileSync(resolve(root, '.env'), [
    'DB_NAME=taskflow', 'DB_USER=taskflow',
    `DB_PASSWORD=${randomBytes(24).toString('hex')}`,
    `JWT_SECRET=${randomBytes(32).toString('hex')}`,
    'ADMIN_EMAIL=admin@taskflow.com', 'ADMIN_PASSWORD=Admin@123',
    'WEB_PORT=4200', 'API_PORT=18080', ''
  ].join('\n'), { mode: 0o600 });
}
const env = readEnv();
if (!env.JWT_SECRET || env.JWT_SECRET.startsWith('REPLACE_') || Buffer.byteLength(env.JWT_SECRET) < 32 || !env.DB_PASSWORD)
  throw new Error('Set DB_PASSWORD and a JWT_SECRET of at least 32 bytes in .env.');
for (const key of ['DB_NAME', 'DB_USER', 'DB_PASSWORD']) {
  if (!/^[A-Za-z0-9_]+$/.test(env[key] ?? '') || env[key].startsWith('REPLACE_'))
    throw new Error(`Set ${key} to a real alphanumeric/underscore value in .env.`);
}
const secretPath = resolve(root, 'k8s/secret.local.yaml');
if (!existsSync(secretPath)) {
  const values = {
    POSTGRES_PASSWORD: env.DB_PASSWORD,
    ConnectionStrings__Database: `Host=database;Port=5432;Database=${env.DB_NAME};Username=${env.DB_USER};Password=${env.DB_PASSWORD}`,
    Jwt__Key: env.JWT_SECRET, Auth__Password: env.ADMIN_PASSWORD
  };
  const data = Object.entries(values).map(([key, value]) => `  ${key}: ${Buffer.from(value).toString('base64')}`).join('\n');
  writeFileSync(secretPath, `apiVersion: v1\nkind: Secret\nmetadata:\n  name: taskflow-secrets\ntype: Opaque\ndata:\n${data}\n`, { mode: 0o600 });
}
console.log('Ready: .env and k8s/secret.local.yaml. Keep both private and out of Git.');
