import { spawn } from 'node:child_process';
import { readEnv, root } from './env.mjs';

const config = { ...readEnv(), ...process.env };
const env = {
  ...process.env,
  ASPNETCORE_ENVIRONMENT: 'Development',
  ASPNETCORE_URLS: `http://127.0.0.1:${config.API_PORT ?? '18080'}`,
  ConnectionStrings__Database: config.ConnectionStrings__Database ??
    `Host=${config.DB_HOST ?? 'localhost'};Port=${config.DB_PORT ?? '5432'};Database=${config.DB_NAME};Username=${config.DB_USER};Password=${config.DB_PASSWORD}`,
  Jwt__Key: config.JWT_SECRET,
  Auth__Email: config.ADMIN_EMAIL,
  Auth__Password: config.ADMIN_PASSWORD
};
const child = spawn('dotnet', ['run', '--project', 'backend', '--no-launch-profile'], { cwd: root, env, stdio: 'inherit', windowsHide: true });
child.on('error', error => { console.error(error.message); process.exitCode = 1; });
child.on('exit', code => { process.exitCode = code ?? 0; });
process.on('SIGINT', () => child.kill('SIGINT'));
process.on('SIGTERM', () => child.kill('SIGTERM'));
