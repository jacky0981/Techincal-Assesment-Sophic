# Simple version: verification

Verified on 2026-09-18:

- ASP.NET API builds successfully.
- Angular production build passes.
- The existing 18 HTTP API tests passed against the simplified API before the extra test project was removed.
- Browser checks passed for guarded routes, login validation/failure/success, create/edit, Done/Undo, delete, and logout.
- Live PostgreSQL checks passed for all task endpoints and task persistence after an API restart.
- The included migration applied on a fresh database and reran safely on restart.
- Docker/Kubernetes YAML parsed successfully before removing the extra validator package.
- npm reports zero known vulnerabilities after removing the test tooling.

The live check used an isolated PostgreSQL 18.4 database, not the Docker PostgreSQL 17 image.
Temporary services were stopped afterward; existing databases were not changed.
Desktop and mobile screens were reviewed; the mobile table uses horizontal scrolling.

To keep the delivered project simple, CI, automated test projects, and extra test packages were removed.
The earlier tests remain recoverable on the advanced-version Git branch.

Not verified here: Docker Compose execution and Kubernetes deployment, because Docker/kubectl/a cluster are unavailable.
No remote repository was published and no submission email was sent.
Follow README.md for setup and the remaining deployment checks.
