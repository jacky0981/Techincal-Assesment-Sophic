# Simple design decisions

1. Use Angular, ASP.NET Core, and PostgreSQL because the assessment explicitly requires them; React would not meet it.
2. Keep only Login and Tasks pages. A single form creates or edits tasks; a normal table lists them.
3. Angular Reactive Forms validate input. A route guard protects navigation; an interceptor attaches the stored JWT. Backend authorization independently protects every task endpoint.
4. Keep Controller -> Service -> Repository separation because it is a stated requirement. EF Core handles PostgreSQL and includes a migration.
5. Use the single assessment admin account from environment configuration. JWTs expire after 60 minutes. This is a learning/assessment app, not production identity management.
6. Store only the JWT session in localStorage as allowed by the brief. Logout clears it; existing tokens remain valid until expiry. Real production auth would need stronger identity and token management.
7. No secrets are committed. One small setup helper creates private local configuration with random DB/JWT secrets.
8. Apply migrations at startup for one backend instance. Multiple production replicas would need a separate migration job.
9. Keep the required Docker and Kubernetes files. Remove optional Ingress, CI, browser-test tooling, dashboard styling, counters, and extra helper scripts.
10. PDF section 5 duplicates backend requirements. Implement those on the server; use the explicit Angular requirements for the frontend.
11. .NET 8 matches the installed runtime and required ASP.NET stack. Upgrade before its support ends in November 2026 if this project is kept long-term.
12. Optional descriptions/dates may be null; deadlines may be in the past. PUT preserves status; PATCH explicitly sets Todo/Done.

The advanced implementation remains recoverable in Git history. This version intentionally favors a small, understandable codebase.
