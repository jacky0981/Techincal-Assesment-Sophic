using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskFlow.Api.Contracts;
using TaskFlow.Api.Services;

namespace TaskFlow.Api.Controllers;

[ApiController, Route("api/auth")]
public sealed class AuthController(IAuthService auth) : ControllerBase
{
    [HttpPost("login"), AllowAnonymous]
    public ActionResult<LoginResponse> Login(LoginRequest request)
    {
        var result = auth.Login(request);
        return result is null
            ? Unauthorized(new ApiError("invalid_credentials", "Email or password is incorrect.", HttpContext.TraceIdentifier))
            : Ok(result);
    }
}
