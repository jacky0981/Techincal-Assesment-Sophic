using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskFlow.Api.Contracts;
using TaskFlow.Api.Services;

namespace TaskFlow.Api.Controllers;

[ApiController, Authorize, Route("api/tasks")]
public sealed class TasksController(ITaskService tasks) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<TaskResponse>>> List(CancellationToken ct) =>
        Ok(await tasks.ListAsync(ct));

    [HttpPost]
    public async Task<ActionResult<TaskResponse>> Create(TaskRequest request, CancellationToken ct)
    {
        var task = await tasks.CreateAsync(request, ct);
        return Created($"/api/tasks/{task.Id}", task);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<TaskResponse>> Update(Guid id, TaskRequest request, CancellationToken ct) =>
        Ok(await tasks.UpdateAsync(id, request, ct));

    [HttpPatch("{id:guid}/status")]
    public async Task<ActionResult<TaskResponse>> Status(Guid id, StatusRequest request, CancellationToken ct) =>
        Ok(await tasks.SetStatusAsync(id, request, ct));

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await tasks.DeleteAsync(id, ct);
        return NoContent();
    }
}
