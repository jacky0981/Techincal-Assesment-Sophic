using TaskFlow.Api.Contracts;
using TaskFlow.Api.Models;
using TaskFlow.Api.Repositories;

namespace TaskFlow.Api.Services;

public sealed class TaskNotFoundException : Exception;

public interface ITaskService
{
    Task<List<TaskResponse>> ListAsync(CancellationToken ct);
    Task<TaskResponse> CreateAsync(TaskRequest request, CancellationToken ct);
    Task<TaskResponse> UpdateAsync(Guid id, TaskRequest request, CancellationToken ct);
    Task<TaskResponse> SetStatusAsync(Guid id, StatusRequest request, CancellationToken ct);
    Task DeleteAsync(Guid id, CancellationToken ct);
}

public sealed class TaskService(ITaskRepository repository) : ITaskService
{
    public async Task<List<TaskResponse>> ListAsync(CancellationToken ct) =>
        (await repository.ListAsync(ct)).Select(TaskResponse.From).ToList();

    public async Task<TaskResponse> CreateAsync(TaskRequest request, CancellationToken ct)
    {
        var task = new TaskItem();
        Apply(task, request);
        repository.Add(task);
        await repository.SaveAsync(ct);
        return TaskResponse.From(task);
    }

    public async Task<TaskResponse> UpdateAsync(Guid id, TaskRequest request, CancellationToken ct)
    {
        var task = await GetAsync(id, ct);
        Apply(task, request);
        await repository.SaveAsync(ct);
        return TaskResponse.From(task);
    }

    public async Task<TaskResponse> SetStatusAsync(Guid id, StatusRequest request, CancellationToken ct)
    {
        var task = await GetAsync(id, ct);
        task.Status = request.Status!.Value;
        await repository.SaveAsync(ct);
        return TaskResponse.From(task);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        repository.Remove(await GetAsync(id, ct));
        await repository.SaveAsync(ct);
    }

    private async Task<TaskItem> GetAsync(Guid id, CancellationToken ct) =>
        await repository.FindAsync(id, ct) ?? throw new TaskNotFoundException();

    private static void Apply(TaskItem task, TaskRequest request)
    {
        task.Title = request.Title.Trim();
        task.Description = string.IsNullOrWhiteSpace(request.Description) ? null : request.Description.Trim();
        task.Priority = request.Priority!.Value;
        task.DueDate = request.DueDate;
    }
}
