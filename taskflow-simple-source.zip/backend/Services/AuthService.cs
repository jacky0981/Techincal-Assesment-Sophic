using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using TaskFlow.Api.Contracts;

namespace TaskFlow.Api.Services;

public sealed class JwtOptions
{
    public string Key { get; set; } = "";
    public string Issuer { get; set; } = "";
    public string Audience { get; set; } = "";
    public int LifetimeMinutes { get; set; } = 60;
}

public sealed class AuthOptions
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}

public interface IAuthService { LoginResponse? Login(LoginRequest request); }

public sealed class AuthService(IOptions<JwtOptions> jwtOptions, IOptions<AuthOptions> authOptions)
    : IAuthService
{
    public LoginResponse? Login(LoginRequest request)
    {
        var auth = authOptions.Value;
        // Fixed-size hashes avoid length-based early returns during password comparison.
        var supplied = SHA256.HashData(Encoding.UTF8.GetBytes(request.Password));
        var expected = SHA256.HashData(Encoding.UTF8.GetBytes(auth.Password));
        var passwordMatches = CryptographicOperations.FixedTimeEquals(supplied, expected);
        if (!string.Equals(request.Email.Trim(), auth.Email, StringComparison.OrdinalIgnoreCase)
            || !passwordMatches) return null;

        var jwt = jwtOptions.Value;
        var now = DateTimeOffset.UtcNow;
        var expires = now.AddMinutes(jwt.LifetimeMinutes);
        var token = new JwtSecurityToken(jwt.Issuer, jwt.Audience,
            [new Claim(JwtRegisteredClaimNames.Sub, "assessment-admin"),
             new Claim(JwtRegisteredClaimNames.Email, auth.Email),
             new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())],
            now.UtcDateTime, expires.UtcDateTime,
            new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key)),
                SecurityAlgorithms.HmacSha256));
        return new LoginResponse(new JwtSecurityTokenHandler().WriteToken(token), expires);
    }
}
