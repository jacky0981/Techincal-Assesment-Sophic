using Microsoft.EntityFrameworkCore;
using TaskFlow.Api.Models;

namespace TaskFlow.Api.Data;

public sealed class TaskDbContext(DbContextOptions<TaskDbContext> options) : DbContext(options)
{
    public DbSet<TaskItem> Tasks => Set<TaskItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var task = modelBuilder.Entity<TaskItem>();
        task.ToTable("Tasks");
        task.HasKey(t => t.Id);
        task.Property(t => t.Title).IsRequired().HasMaxLength(120);
        task.Property(t => t.Description).HasMaxLength(2000);
        task.Property(t => t.Priority).HasConversion<string>().HasMaxLength(10);
        task.Property(t => t.Status).HasConversion<string>().HasMaxLength(10);
        task.HasIndex(t => t.CreatedAt);
    }
}
