using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace TaskFlow.Api.Data;

public sealed class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<TaskDbContext>
{
    public TaskDbContext CreateDbContext(string[] args)
    {
        // Generating migrations needs no connection. Applying them requires the env connection string.
        var connection = Environment.GetEnvironmentVariable("ConnectionStrings__Database");
        var options = new DbContextOptionsBuilder<TaskDbContext>();
        if (string.IsNullOrWhiteSpace(connection)) options.UseNpgsql();
        else options.UseNpgsql(connection);
        return new TaskDbContext(options.Options);
    }
}
