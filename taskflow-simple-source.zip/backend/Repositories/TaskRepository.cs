using Microsoft.EntityFrameworkCore;
using TaskFlow.Api.Data;
using TaskFlow.Api.Models;

namespace TaskFlow.Api.Repositories;

public interface ITaskRepository
{
    Task<List<TaskItem>> ListAsync(CancellationToken cancellationToken);
    Task<TaskItem?> FindAsync(Guid id, CancellationToken cancellationToken);
    void Add(TaskItem task);
    void Remove(TaskItem task);
    Task SaveAsync(CancellationToken cancellationToken);
}

public sealed class TaskRepository(TaskDbContext db) : ITaskRepository
{
    public Task<List<TaskItem>> ListAsync(CancellationToken ct) => db.Tasks
        .AsNoTracking().OrderByDescending(t => t.CreatedAt).ThenBy(t => t.Id).ToListAsync(ct);
    public Task<TaskItem?> FindAsync(Guid id, CancellationToken ct) =>
        db.Tasks.SingleOrDefaultAsync(t => t.Id == id, ct);
    public void Add(TaskItem task) => db.Tasks.Add(task);
    public void Remove(TaskItem task) => db.Tasks.Remove(task);
    public async Task SaveAsync(CancellationToken ct) => await db.SaveChangesAsync(ct);
}
