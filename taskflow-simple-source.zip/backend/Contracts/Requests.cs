using System.ComponentModel.DataAnnotations;
using TaskFlow.Api.Models;

namespace TaskFlow.Api.Contracts;

public sealed class LoginRequest
{
    [Required, EmailAddress, StringLength(254)]
    public string Email { get; init; } = "";
    [Required, StringLength(128)]
    public string Password { get; init; } = "";
}

public sealed class TaskRequest : IValidatableObject
{
    [Required, StringLength(120)]
    public string Title { get; init; } = "";
    [StringLength(2000)]
    public string? Description { get; init; }
    [Required, EnumDataType(typeof(TaskPriority))]
    public TaskPriority? Priority { get; init; }
    public DateOnly? DueDate { get; init; }

    public IEnumerable<ValidationResult> Validate(ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(Title))
            yield return new ValidationResult("Title must not be blank.", [nameof(Title)]);
    }
}

public sealed class StatusRequest
{
    [Required, EnumDataType(typeof(Models.TaskStatus))]
    public Models.TaskStatus? Status { get; init; }
}

public sealed record LoginResponse(string Token, DateTimeOffset ExpiresAt);
public sealed record TaskResponse(Guid Id, string Title, string? Description,
    TaskPriority Priority, DateOnly? DueDate, Models.TaskStatus Status, DateTimeOffset CreatedAt)
{
    public static TaskResponse From(TaskItem task) => new(task.Id, task.Title,
        task.Description, task.Priority, task.DueDate, task.Status, task.CreatedAt);
}

public sealed record ApiError(string Code, string Message, string TraceId,
    IDictionary<string, string[]>? Errors = null);
