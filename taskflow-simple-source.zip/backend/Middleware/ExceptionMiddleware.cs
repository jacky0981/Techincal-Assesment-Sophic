using Microsoft.EntityFrameworkCore;
using TaskFlow.Api.Contracts;
using TaskFlow.Api.Services;

namespace TaskFlow.Api.Middleware;

public sealed class ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try { await next(context); }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested) { }
        catch (Exception exception)
        {
            if (context.Response.HasStarted) throw;
            var (status, code, message) = exception switch
            {
                TaskNotFoundException => (404, "not_found", "Task was not found. Refresh the list and try again."),
                DbUpdateConcurrencyException => (409, "conflict", "This task changed or was deleted. Refresh and try again."),
                _ => (500, "server_error", "Something went wrong. Please try again later.")
            };
            if (status >= 500) logger.LogError(exception, "Unhandled request error {TraceId}", context.TraceIdentifier);
            context.Response.StatusCode = status;
            await context.Response.WriteAsJsonAsync(new ApiError(code, message, context.TraceIdentifier));
        }
    }
}
